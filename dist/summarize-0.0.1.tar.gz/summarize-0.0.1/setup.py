from setuptools import setup, find_packages

with open('requirements.txt', 'r') as file:
    requirements = [
        line.strip() for line in file
        if line.strip() and not line.strip().startswith('#')
    ]

setup(
    name="summarize",
    version="0.0.1",
    author="Kamran Khan",
    author_email="kamrankhnkami@gmail.com",
    description="demo python CLI tool to summarize text using HuggingFace",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/kamipakistan/packing_your_project",
    packages=find_packages(),
    install_requires=requirements,
    python_requires=">=3.8",
    entry_points={
        "console_scripts": [
            "summarize=HuggingfaceSummarization.main.py:main",
        ],
    },
)
